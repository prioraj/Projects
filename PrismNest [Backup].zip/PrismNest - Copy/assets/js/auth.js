document.addEventListener("DOMContentLoaded", function () {
  // --- Real Authentication Logic ---

  const loginForm = document.getElementById("loginForm");
  const loginAlert = document.getElementById("loginAlert");
  const signupForm = document.getElementById("signupForm");
  const signupAlert = document.getElementById("signupAlert");

  // --- LOGIN ---
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const email = document.getElementById("loginEmail").value.trim();
      const password = document.getElementById("loginPassword").value;

      if (loginAlert) loginAlert.classList.add("d-none");

      // 1. Get users from DB
      const users = getDBUsers(); // Function from data.js

      // 2. Find user with matching email
      let foundUser = null;
      for (let userId in users) {
        if (users[userId].email === email) {
          foundUser = users[userId];
          break;
        }
      }

      // 3. Validate Password
      if (foundUser && foundUser.password === password) {
        console.log("Login successful!");

        // Save Session Data
        localStorage.setItem("prismnest_loggedIn", "true");
        localStorage.setItem(
          "prismnest_currentUser",
          JSON.stringify(foundUser)
        );

        // Set Profile Defaults for script.js to use
        localStorage.setItem("profile_name", foundUser.name);
        localStorage.setItem("profile_username", foundUser.username);
        localStorage.setItem("profile_pic", foundUser.pic);
        localStorage.setItem("profile_cover", foundUser.cover);
        localStorage.setItem("profile_bio", foundUser.bio);

        window.location.href = "index.php";
      } else {
        if (loginAlert) {
          loginAlert.textContent = "Invalid email or password.";
          loginAlert.classList.remove("d-none");
        }
      }
    });
  }

  // --- SIGN UP ---
  if (signupForm) {
    signupForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const username = document.getElementById("signupUsername").value.trim();
      const email = document.getElementById("signupEmail").value.trim();
      const password = document.getElementById("signupPassword").value;

      if (signupAlert) signupAlert.classList.add("d-none");

      // 1. Check password length
      if (password.length < 6) {
        if (signupAlert) {
          signupAlert.textContent = "Password must be at least 6 characters.";
          signupAlert.classList.remove("d-none");
        }
        return;
      }

      // 2. Check if user already exists
      const users = getDBUsers();
      for (let id in users) {
        if (users[id].email === email) {
          if (signupAlert) {
            signupAlert.textContent = "User with this email already exists.";
            signupAlert.classList.remove("d-none");
          }
          return;
        }
      }

      // 3. Create New User Object
      // We use the Username as the ID (simple approach)
      // Remove spaces from username to make a safe ID
      const safeId = username.replace(/\s+/g, "");

      const newUser = {
        id: safeId,
        name: username, // Using username as Name initially
        username: "@" + safeId.toLowerCase(),
        email: email,
        password: password,
        bio: "New to PrismNest!",
        cover: "assets/images/background.png", // Default cover
        pic: "assets/images/temp-profile.jpg", // Default avatar
        followers: [],
        following: [],
      };

      // 4. Save to DB
      users[safeId] = newUser;
      saveDBUsers(users);

      // 5. Auto-Login the user
      localStorage.setItem("prismnest_loggedIn", "true");
      localStorage.setItem("prismnest_currentUser", JSON.stringify(newUser));
      localStorage.setItem("profile_name", newUser.name);
      localStorage.setItem("profile_username", newUser.username);
      localStorage.setItem("profile_pic", newUser.pic);

      alert("Account created successfully!");
      window.location.href = "index.php";
    });
  }

  // --- AUTH GUARD (Security) ---
  // Logic to kick out non-logged in users
  const protectedPages = [
    "index.php",
    "profile.php",
    "settings.php",
    "notifications.php",
    "search-results.php",
  ];
  const currentPage = window.location.pathname.split("/").pop();

  if (protectedPages.includes(currentPage) || currentPage === "") {
    const isLoggedIn = localStorage.getItem("prismnest_loggedIn");
    if (!isLoggedIn) {
      window.location.href = "login.php";
    }
  }
});
