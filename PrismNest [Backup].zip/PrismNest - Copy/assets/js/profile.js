document.addEventListener("DOMContentLoaded", function () {
  // ===================================================================
  // 1. INITIALIZATION & ELEMENT SELECTION
  // ===================================================================
  const postsCountEl = document.getElementById("postsCount");
  const followersCountEl = document.getElementById("followersCount");
  const followingCountEl = document.getElementById("followingCount");
  const postsGrid = document.getElementById("postsGrid");
  const savedGrid = document.getElementById("savedGrid");
  const profileTabsContainer = document.querySelector(".profile-tabs-wrapper");
  const copyProfileLinkBtn = document.getElementById("copyProfileLinkBtn");

  // Edit Profile Elements
  const editProfileModalEl = document.getElementById("editProfileModal");
  const editProfileModal = editProfileModalEl
    ? new bootstrap.Modal(editProfileModalEl)
    : null;
  const coverPhotoUpload = document.getElementById("coverPhotoUpload");
  const profilePhotoUpload = document.getElementById("profilePhotoUpload");
  const coverPhotoPreview = document.getElementById("coverPhotoPreview");
  const profilePhotoPreview = document.getElementById("profilePhotoPreview");
  const editNameInput = document.getElementById("editName");
  const editUsernameInput = document.getElementById("editUsername");
  const editBioInput = document.getElementById("editBio");
  const saveProfileChangesBtn = document.getElementById("saveProfileChanges");

  // Cropper Elements
  const cropperModalEl = document.getElementById("imageCropperModal");
  const cropperModal = cropperModalEl
    ? new bootstrap.Modal(cropperModalEl)
    : null;
  const imageToCrop = document.getElementById("imageToCrop");
  const cropImageBtn = document.getElementById("cropImageBtn");

  // Profile UI Elements
  const mainCoverPhoto = document.querySelector(".main-cover-photo");
  const mainProfilePics = document.querySelectorAll(".main-profile-pic");
  const profileName = document.querySelector(".profile-name");
  const profileUsername = document.querySelector(".profile-username");
  const profileBio = document.getElementById("profileBio");
  const profileActions = document.querySelector(".profile-actions");

  // State
  let cropper;
  let currentCropTarget = null;

  // Get Real Data directly from LocalStorage to ensure sync
  // We do not use global variables here to avoid stale data
  function getFreshUsers() {
    return JSON.parse(localStorage.getItem("prismnest_users")) || {};
  }
  function getFreshPosts() {
    return JSON.parse(localStorage.getItem("prismnest_posts")) || [];
  }

  const currentUser = JSON.parse(localStorage.getItem("prismnest_currentUser"));

  // ===================================================================
  // 2. CORE FUNCTIONS (REAL DATA LOGIC)
  // ===================================================================

  function renderPostGrid(posts, container) {
    container.innerHTML = "";
    if (posts.length === 0) {
      container.innerHTML = `
            <div class="col-12">
                <div class="empty-state-card card p-5 text-center">
                    <i class="bi bi-camera-reels fs-1"></i>
                    <h5 class="mt-3">No Posts Yet</h5>
                    <p class="text-muted">Capture moments to show them here.</p>
                </div>
            </div>`;
      return;
    }

    let html = '<div class="row g-2">';
    posts.forEach((post) => {
      html += `
            <div class="col-4">
              <img src="${post.postImage}" alt="Post" class="img-fluid rounded" style="aspect-ratio: 1/1; object-fit: cover; cursor: pointer;">
            </div>`;
    });
    html += "</div>";
    container.innerHTML = html;
  }

  function loadProfile(targetUserId) {
    const dbUsers = getFreshUsers();
    const dbPosts = getFreshPosts();

    // 1. Get the User Object from DB
    const user = dbUsers[targetUserId];

    if (!user) {
      console.error("User not found");
      return;
    }

    // 2. Update Basic Info
    if (profileName) profileName.textContent = user.name;
    if (profileUsername) profileUsername.textContent = user.username;
    if (profileBio) profileBio.textContent = user.bio;
    if (mainCoverPhoto) mainCoverPhoto.src = user.cover;
    if (mainProfilePics) mainProfilePics.forEach((img) => (img.src = user.pic));

    // 3. REAL STATS CALCULATION
    const followers = user.followers || [];
    const following = user.following || [];
    // Filter posts belonging to this user
    const userPosts = dbPosts.filter((p) => p.userId === targetUserId);

    if (followersCountEl) followersCountEl.textContent = followers.length;
    if (followingCountEl) followingCountEl.textContent = following.length;
    if (postsCountEl) postsCountEl.textContent = userPosts.length;

    // 4. Render Post Grid
    userPosts.sort((a, b) => new Date(b.time) - new Date(a.time));
    if (postsGrid) renderPostGrid(userPosts, postsGrid);

    // 5. Handle "Edit Profile" vs "Follow" Button
    if (profileActions) {
      if (currentUser && currentUser.id === targetUserId) {
        // Viewing my own profile
        profileActions.innerHTML = `
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit Profile</button>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary" type="button" data-bs-toggle="dropdown"><i class="bi bi-box-arrow-up"></i></button>
                    <ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="#" id="copyProfileLinkBtn">Copy Profile Link</a></li></ul>
                </div>`;

        // Re-attach copy link listener since we rewrote HTML
        const newCopyBtn = document.getElementById("copyProfileLinkBtn");
        if (newCopyBtn) {
          newCopyBtn.addEventListener("click", (e) => {
            e.preventDefault();
            navigator.clipboard.writeText(window.location.href);
            alert("Link copied!");
          });
        }
      } else {
        // Viewing someone else
        // Check if I follow them (using fresh data)
        const myFreshData = dbUsers[currentUser.id];
        const isFollowing =
          myFreshData &&
          myFreshData.following &&
          myFreshData.following.includes(targetUserId);

        const btnText = isFollowing ? "Following" : "Follow";
        const btnClass = isFollowing ? "btn-secondary" : "btn-primary";

        profileActions.innerHTML = `
                <button class="btn ${btnClass}" id="profileFollowBtn">${btnText}</button>
                <button class="btn btn-outline-secondary">Message</button>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary" type="button" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical"></i></button>
                    <ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item text-danger" href="#">Report</a></li></ul>
                </div>`;

        // Attach Listener for Follow Button
        document
          .getElementById("profileFollowBtn")
          .addEventListener("click", function () {
            toggleFollow(targetUserId, this);
          });
      }
    }

    document.title = `${user.name} (${user.username}) - PrismNest`;
  }

  function toggleFollow(targetId, btn) {
    // Refresh data before writing
    let dbUsers = getFreshUsers();
    let me = dbUsers[currentUser.id];
    let targetUser = dbUsers[targetId];

    if (!me.following) me.following = [];
    if (!targetUser.followers) targetUser.followers = [];

    const isFollowing = me.following.includes(targetId);

    if (isFollowing) {
      // Unfollow
      me.following = me.following.filter((id) => id !== targetId);
      targetUser.followers = targetUser.followers.filter(
        (id) => id !== currentUser.id
      );

      btn.textContent = "Follow";
      btn.classList.replace("btn-secondary", "btn-primary");
    } else {
      // Follow
      me.following.push(targetId);
      targetUser.followers.push(currentUser.id);

      btn.textContent = "Following";
      btn.classList.replace("btn-primary", "btn-secondary");
    }

    // Save everything back to DB
    dbUsers[currentUser.id] = me;
    dbUsers[targetId] = targetUser;
    localStorage.setItem("prismnest_users", JSON.stringify(dbUsers));

    // Also update session
    localStorage.setItem("prismnest_currentUser", JSON.stringify(me));

    // Update the stats number immediately on screen
    if (followersCountEl)
      followersCountEl.textContent = targetUser.followers.length;
  }

  function loadSavedPosts() {
    if (!savedGrid) return;
    const dbPosts = getFreshPosts();
    // Find posts where savedBy includes current user ID
    const savedPosts = dbPosts.filter(
      (p) => p.savedBy && p.savedBy.includes(currentUser.id)
    );
    renderPostGrid(savedPosts, savedGrid);
  }

  // ===================================================================
  // 3. EDIT PROFILE LOGIC
  // ===================================================================

  function openCropper(imageFile, target, aspectRatio) {
    if (!imageFile) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      imageToCrop.src = e.target.result;
      currentCropTarget = target;
      cropperModal.show();
      cropperModalEl.addEventListener(
        "shown.bs.modal",
        () => {
          if (cropper) cropper.destroy();
          cropper = new Cropper(imageToCrop, {
            aspectRatio: aspectRatio,
            viewMode: 1,
          });
        },
        { once: true }
      );
    };
    reader.readAsDataURL(imageFile);
  }

  if (editProfileModalEl) {
    editProfileModalEl.addEventListener("show.bs.modal", () => {
      // Always get fresh data for the modal
      const freshUser = getFreshUsers()[currentUser.id];

      editNameInput.value = freshUser.name;
      editUsernameInput.value = freshUser.username;
      editBioInput.value = freshUser.bio;
      coverPhotoPreview.src = freshUser.cover;
      profilePhotoPreview.src = freshUser.pic;
    });

    saveProfileChangesBtn.addEventListener("click", () => {
      let dbUsers = getFreshUsers();
      let me = dbUsers[currentUser.id];

      // Update Object
      me.name = editNameInput.value;
      me.username = editUsernameInput.value;
      me.bio = editBioInput.value;
      me.cover = coverPhotoPreview.src;
      me.pic = profilePhotoPreview.src;

      // Save to DB
      dbUsers[currentUser.id] = me;
      localStorage.setItem("prismnest_users", JSON.stringify(dbUsers));
      localStorage.setItem("prismnest_currentUser", JSON.stringify(me));

      // Refresh Page UI
      loadProfile(currentUser.id);
      editProfileModal.hide();

      // Force reload to update navbar image if needed
      location.reload();
    });

    coverPhotoUpload.addEventListener("change", () =>
      openCropper(coverPhotoUpload.files[0], "cover", 16 / 9)
    );
    profilePhotoUpload.addEventListener("change", () =>
      openCropper(profilePhotoUpload.files[0], "profile", 1 / 1)
    );
  }

  if (cropperModalEl) {
    cropImageBtn.addEventListener("click", () => {
      if (!cropper) return;
      const url = cropper.getCroppedCanvas().toDataURL("image/jpeg");
      if (currentCropTarget === "profile") profilePhotoPreview.src = url;
      else if (currentCropTarget === "cover") coverPhotoPreview.src = url;
      cropper.destroy();
      cropperModal.hide();
    });
  }

  // ===================================================================
  // 4. INITIAL EXECUTION
  // ===================================================================

  // Tab Switching
  if (profileTabsContainer) {
    const tabPanes = document.querySelectorAll(
      ".profile-grid-container .tab-pane"
    );
    profileTabsContainer.addEventListener("click", function (e) {
      const clickedTab = e.target.closest(".feed-tab");
      if (!clickedTab || clickedTab.classList.contains("active")) return;
      profileTabsContainer
        .querySelectorAll(".feed-tab")
        .forEach((tab) => tab.classList.remove("active"));
      clickedTab.classList.add("active");
      const targetId = clickedTab.dataset.target;
      tabPanes.forEach((pane) => {
        if (`#${pane.id}` === targetId) pane.classList.add("active");
        else pane.classList.remove("active");
      });
    });
  }

  // Determine which profile to load
  const urlParams = new URLSearchParams(window.location.search);
  const paramId = urlParams.get("user");

  // If ?user=... exists, load that user. Otherwise load ME.
  const targetUserId = paramId ? paramId : currentUser.id;

  loadProfile(targetUserId);

  // Only load saved posts if viewing my own profile
  if (targetUserId === currentUser.id) {
    loadSavedPosts();
  }
});
